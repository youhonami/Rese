<!DOCTYPE html>
<html lang="ja">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sanitize.css">
    <link rel="stylesheet" href="<?php echo e(asset('css/layout.css')); ?>">
    <?php echo $__env->yieldContent('styles'); ?>
</head>

<body>
    <input type="checkbox" id="menu-toggle" class="menu-toggle">

    <div class="menu-modal">
        <label for="menu-toggle" class="close-btn">✕</label>
        <ul>
            <li><a href="<?php echo e(route('shops.index')); ?>">Home</a></li>

            <?php if(auth()->guard()->check()): ?>
            <li>
                <form method="POST" action="<?php echo e(route('logout')); ?>">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="link-btn">Logout</button>
                </form>
            </li>

            
            <?php if(Auth::user()->role === 'user'): ?>
            <li><a href="<?php echo e(route('mypage')); ?>">Mypage</a></li>
            <?php endif; ?>


            
            <?php if(Auth::user()->role === 'representative'): ?>
            <li><a href="<?php echo e(route('representative.dashboard')); ?>">店舗代表者ページ</a></li>
            <?php endif; ?>

            
            <?php if(Auth::user()->role === 'admin'): ?>
            <li><a href="<?php echo e(route('admin.dashboard')); ?>">管理者ページ</a></li>
            <?php endif; ?>
            <?php else: ?>
            <li><a href="<?php echo e(route('register')); ?>">Registration</a></li>
            <li><a href="<?php echo e(route('login')); ?>">Login</a></li>
            <?php endif; ?>
        </ul>
    </div>


    <header>
        <div class="logo">
            <label for="menu-toggle" class="menu-icon">&#9776;</label>
            <a href="<?php echo e(route('shops.index')); ?>">Rese</a>
        </div>

        
        <?php if(Route::currentRouteName() === 'shops.index'): ?>
        <div class="filter">
            <form action="<?php echo e(route('shops.index')); ?>" method="GET">
                <select name="area">
                    <option value="">All area</option>
                    <?php $__currentLoopData = $areas ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($area); ?>" <?php echo e(request('area') == $area ? 'selected' : ''); ?>>
                        <?php echo e($area); ?>

                    </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

                <select name="genre">
                    <option value="">All genre</option>
                    <?php $__currentLoopData = $genres ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($genre); ?>" <?php echo e(request('genre') == $genre ? 'selected' : ''); ?>>
                        <?php echo e($genre); ?>

                    </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

                <input type="text" name="keyword" placeholder="Search ..." value="<?php echo e(request('keyword')); ?>">
            </form>
        </div>
        <?php endif; ?>
    </header>

    <main>
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <?php echo $__env->yieldContent('scripts'); ?>
</body>

</html><?php /**PATH /var/www/resources/views/layouts/layout.blade.php ENDPATH**/ ?>