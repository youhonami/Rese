<?php $__env->startSection('title', 'Rese - 飲食店一覧'); ?>

<?php $__env->startSection('styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/index.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="shop-container">
    <?php $__currentLoopData = $shops; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shop): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="shop-card">
        <img src="<?php echo e(asset('storage/' . $shop->img)); ?>" alt="<?php echo e($shop->shop_name); ?>">
        <div class="shop-info">
            <h2><?php echo e($shop->shop_name); ?></h2>
            <p>#<?php echo e($shop->area); ?> #<?php echo e($shop->genre); ?></p>
            <div class="shop-footer">
                <a href="<?php echo e(route('shops.detail', ['shop' => $shop->id])); ?>" class="btn">詳しくみる</a>
                <?php if(auth()->guard()->check()): ?>
                <?php if(Auth::user()->role === 'user'): ?>
                <button class="heart-btn" data-shop-id="<?php echo e($shop->id); ?>">
                    <?php echo e(Auth::user()->favorites->contains($shop->id) ? '❤️' : '♡'); ?>

                </button>
                <?php else: ?>
                <span class="heart-disabled">♡</span>
                <?php endif; ?>
                <?php endif; ?>
                <?php if(auth()->guard()->guest()): ?>
                <span class="heart-disabled">♡</span>
                <?php endif; ?>
            </div>

        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        document.querySelectorAll('.heart-btn').forEach(button => {
            button.addEventListener('click', function(e) {
                e.preventDefault();

                const shopId = this.dataset.shopId;
                const isLiked = this.textContent.trim() === '❤️';
                const token = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

                fetch(`/favorites/${shopId}`, {
                        method: isLiked ? 'DELETE' : 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-CSRF-TOKEN': token,
                            'X-Requested-With': 'XMLHttpRequest'
                        },
                        body: isLiked ? null : JSON.stringify({
                            shop_id: shopId
                        })
                    })
                    .then(response => {
                        if (response.ok) {
                            this.textContent = isLiked ? '♡' : '❤️';
                        } else {
                            alert('エラーが発生しました');
                        }
                    });
            });
        });
    });
</script>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        const area = document.querySelector('[name="area"]');
        const genre = document.querySelector('[name="genre"]');
        const keyword = document.querySelector('[name="keyword"]');
        const container = document.querySelector('.shop-container');

        function fetchShops() {
            const params = new URLSearchParams({
                area: area.value,
                genre: genre.value,
                keyword: keyword.value
            });

            fetch(`/api/shops/search?${params}`)
                .then(res => res.json())
                .then(data => {
                    container.innerHTML = '';
                    if (data.length === 0) {
                        container.innerHTML = '<p>該当する店舗がありません。</p>';
                        return;
                    }

                    data.forEach(shop => {
                        const heartIcon = shop.is_favorite ? '❤️' : '♡';
                        const shopCard = `
        <div class="shop-card">
            <img src="/storage/${shop.img}" alt="${shop.shop_name}">
            <div class="shop-info">
                <h2>${shop.shop_name}</h2>
                <p>#${shop.area} #${shop.genre}</p>
                <div class="shop-footer">
                    <a href="/detail/${shop.id}" class="btn">詳しくみる</a>
                    <button class="heart-btn" data-shop-id="${shop.id}">${heartIcon}</button>
                </div>
            </div>
        </div>
    `;
                        container.insertAdjacentHTML('beforeend', shopCard);
                    });
                })
                .catch(err => {
                    console.error('検索エラー:', err);
                });
        }

        area.addEventListener('change', fetchShops);
        genre.addEventListener('change', fetchShops);
        keyword.addEventListener('input', fetchShops);
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/resources/views/index.blade.php ENDPATH**/ ?>