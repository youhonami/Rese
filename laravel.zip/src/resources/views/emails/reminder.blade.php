<p>{{ $reservation->user->name }}様</p>
<p>本日 {{ $reservation->time }} より、{{ $reservation->shop->shop_name }} での予約があります。</p>
<p>ご来店をお待ちしております！</p>